"""
GRUPO:
- Camily Albres
- Daniela Lima
- Eduardo Lago
- Mateus Marcimiano

REQUISITOS:
- pygame | pip install pygame
- tabulate | pip install tabulate


!!!!!!!!!!!!!!!!!!!!!!
!!!   INSTRUÇÕES   !!!
!!!!!!!!!!!!!!!!!!!!!!


Ctrl + Shift + Alt + L  --> Formata o codigo
Ctrl + D  --> Duplica a linha

1. Sempre que quiser pedir uma ação do usuário
use a função opt_select(), (ex. Linha 176 - cód. original)
pois ela vaia te retornar um valor para o user_in (input do usuário)

Dica: use-a junto da funcao gen_tab(), pra mostrar as opcoes na tela primeiro (ex. Linha 263 e 264)
    gen_tab()
    opt_select()

2. Se que quiser fazer o efeito de digitação no texto, utilize a função
typing_fx(texto_01) - crie uma variável do tipo string e use-a como parâmetro
nessa função. (ex. a variável texto_01 (Linha 87))

3. Quando você quiser mostrar a tabela de opções para o usuário, utilize a função
gen_tab() - use acao como parâmetro para mostrar a tabela de ações | use suspeitos
para mostrar a tabela de suspeito

        se quiser fazer sua própria tabela - https://towardsdatascience.com/how-to-easily-create-tables-in-python-2eaea447d8fd

4. Para comentar um bloco de código Ctrl + /
(se vc quiser testar algo, por exemplo, e ta demorando pq tem q esperar por um sleep
ou pular partes... ex. comenta as funções de typing_fx pra nao ter q ficar esperando
o texto ser digitado)

5. Evite mexer no resto do código... Pode alterar os textos/história se quiser

6. !!!!!!!!!!!!!!!!!!!!!! Cuidado com a identação !!!!!!!!!!!!!!!!!!!!!!!!!

Se preferir, faça a parte das escolhar num arquivo separado e dps eu junto com esse


A parte de inserir pistas na tabela pra mostrar eu faço dps...
Pra agora falta a parte de if/elif/else pra fazer

Escolha uma ação:
    1 | AAAAA
    2 | BBBBB
    3 | CCCCC

Escolha um suspeito:
    1 | AAAAA
    2 | BBBBB
    3 | CCCCC

if ação == 1:
    if suspeito == 1:
        XXXXXX
    elif suspeito == 2:
        XXXXXX
    else:
        XXXXXX

elif ação == 2:
    if suspeito == 1:
        XXXXXX
    elif suspeito == 2:
        XXXXXX
    else:
        XXXXXX


tipo isso... a conexão com o resto do cod eu faço dps






{ (( p ∨ q ) → r ) ,  ( s → p ) , ( t → q ) , ( s ∨ t ) } ⊨  u ∨ r

1. ( p ∨ q ) → r
2. s → p
3. t → q
4. s ∨ t
5. p ∨ q	D.C.[2, 3, 4]
6. r		M.P.[1, 5]
7. ( p ∨ q ) ∧ r
8. u ∨ r	ADD[6]

p: o jardineiro estava podando o jardim
q: a faxineira estava limpando a varanda
r: o mordomo estava sozinho em casa com a dona da casa
s: a faxineira avistou o jardineiro com uma tesoura de poda no jardim
t: o jardineiro disse que a faxineira estava limpando vidro quebrado na varanda
u: o mordomo foi ao mercado

"""

from random import choice
from time import sleep

from pygame import mixer
from tabulate import tabulate

# PYGAME MIXER
# Sfx
mixer.init()
mixer.music.load("sfx_enter.mp3")
mixer.music.load("sfx_soundtrack_menu.mp3")
mixer.music.load("sfx_typing.mp3")
sfx_enter = mixer.Sound("sfx_enter.mp3")
sfx_menu = mixer.Sound("sfx_soundtrack_menu.mp3")
sfx_typing = mixer.Sound("sfx_typing.mp3")
# Background Music
mixer.music.load("sfx_soundtrack_main.mp3")

# VARIÁVEIS GLOBAIS
contador_mordomo = 0
contador_jardineiro = 0
contador_faxineira = 0
txt_fx_vel = [0.02, 0.05, 0.08]

# ARRAYS
pistas = [
    "A faxineira avistou o jardineiro com uma tesoura de poda no jardim.",  # s | s->p
    "O jardineiro avistou a faxineira limpando vidro quebrado na varanda.",  # t | t->q
    """Se o jardineiro estava podando o jardim ou a faxineira estava limpando a varanda, 
    então, o mordomo estava sozinho em casa com a dona da casa.""",  # (p v q) -> r
    """É verdade que faxineira avistou o jardineiro com uma tesoura de poda no jardim ou 
     que o jardineiro disse que a faxineira estava limpando vidro quebrado na varanda?""",  # p v q

]

pistas_tab = [
    ["PISTAS"],
    ["insira as"],
    ["pistas"],
    ["aki"],
    ["Dica: Ctrl + D pra duplicar a linha"],
]

acoes = [
    ["Opções", "Ação"],
    ["1", "Interrogar"],
    ["2", "Acusar"],
    ["3", "Consultar pistas"],
]

suspeitos = [
    ["Opções", "Suspeitos"],
    ["1", "Faxineira"],
    ["2", "Jardineiro"],
    ["3", "Mordomo"],
]

# TEXTOS
texto_01 = """- Na tarde de uma quinta-feira, a polícia civil da região metropolitana
de Curitiba foi chamada para investigar um caso de assassinato
occorrido há poucos minutos, na casa de uma senhora muito influente
na cidade.

- O mordomo os recepcionou e disse foi ele quem ligou para a polícia.

- Disse também que na casa estavam presentes o jardineiro e a faxineira
durante o ocorrido.

- Os policiais, então, partiram para interrogar um por um no local do crime.

A partir de agora, cabe a você descobrir quem é o assassino.
"""


# FUNÇÕES
# Typing FX
def typing_fx(text):
    while True:
        sfx_typing.play()
        for i in range(len(text)):
            print(text[i], end="")
            sleep(choice(txt_fx_vel))
        sleep(0.03)
        sfx_typing.stop()
        break


# Gerar Tabela
def gen_tab(tabela):
    x = None
    if not tabela == "pistas_tab":
        x = "firstrow"
    print(tabulate(tabela, headers=x, tablefmt="fancy_grid"))


# Selecionar
def opt_select():
    while True:
        user_in = str(input("Selecione uma opção: ")).strip()
        sfx_enter.play()
        if len(user_in) == 1 and user_in in '123':
            user_in = int(user_in)
            break
        print("Digite apenas um número entre 1 e 3!")
    return user_in


# INÍCIO

# Regras
sfx_menu.play()

print("""
   ______________________________
 / \                             \.
|   |           𝗥𝗘𝗚𝗥𝗔𝗦           |.
 \_ |                            |.
    |  1. Você será o investiga- |.
    |     dor chefe da operação. |.
    |                            |.
    |  2. Você deve descobrir    |.
    |     quem é o assassino     |.
    |     com base nas pistas.   |.
    |                            |.
    |  3. Não há tempo limite.   |.
    |                            |.
    |  4. O jogo acaba quando    |.
    |     alguém for preso.      |.
    |                            |.
    |  5. Você ganha o jogo se   |.
    |     acertar quem era o     |.
    |     assassino, caso con-   |.
    |     trário, você perde.    |.
    |   _________________________|___
    |  /                            /.
    \_/____________________________/.
    """)

while True:
    user_in = str(input("Pressione [Enter] para iniciar:"))
    if user_in == "":
        sfx_menu.stop()
        sfx_enter.play()
        break
    print("Pressione apenas [Enter] para iniciar!")

print("\n" * 100)  # faz sumir as regras da dela
sleep(2)

# Jogo
mixer.music.play()

# typing_fx(texto_01)


# !!!!!  NÃO EXECUTE ESSA PARTE  !!!!!

while True:
    gen_tab(acoes)
    user_in = opt_select()
    if user_in == 1:  # Investigar
        pass  # Faça aqui as condições - !!! tira esse pass quando for escrever o cod.

    elif user_in == 2:  # Acusar
        gen_tab(suspeitos)
        user_in = opt_select()

        if user_in == 1 or user_in == 2:  # Acusou o jardineiro ou a faxineira
            print("""
        ██████╗ ███████╗██████╗ ██████╗  ██████╗ ████████╗ █████╗
        ██╔══██╗██╔════╝██╔══██╗██╔══██╗██╔═══██╗╚══██╔══╝██╔══██╗
        ██║  ██║█████╗  ██████╔╝██████╔╝██║   ██║   ██║   ███████║
        ██║  ██║██╔══╝  ██╔══██╗██╔══██╗██║   ██║   ██║   ██╔══██║
        ██████╔╝███████╗██║  ██║██║  ██║╚██████╔╝   ██║   ██║  ██║
        ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝    ╚═╝   ╚═╝  ╚═╝

        É uma pena. Você deixou o assassino impune.
            """)
        else:  # Acusou o mordomo
            print("""
                                  █
        ██╗   ██╗██╗████████╗ ██████╗ ██████╗ ██╗ █████╗
        ██║   ██║██║╚══██╔══╝██╔═══██╗██╔══██╗██║██╔══██╗
        ██║   ██║██║   ██║   ██║   ██║██████╔╝██║███████║
        ╚██╗ ██╔╝██║   ██║   ██║   ██║██╔══██╗██║██╔══██║
         ╚████╔╝ ██║   ██║   ╚██████╔╝██║  ██║██║██║  ██║
          ╚═══╝  ╚═╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝╚═╝╚═╝  ╚═╝

        Parabéns, você acertou!
            """)
        break
    else:  # Mostrar pistas
        gen_tab(pistas_tab)

print("FIM.")
