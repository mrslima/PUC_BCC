from random import choice
from time import sleep
from tabulate import tabulate

contador_mordomo = 0
contador_jardineiro = 0
contador_faxineira = 0

pistas = [
    "A faxineira avistou o jardineiro com uma tesoura de poda no jardim.",  # s | s->p
    "O jardineiro avistou a faxineira limpando vidro quebrado na varanda.",  # t | t->q
    """Se o jardineiro estava podando o jardim ou a faxineira estava limpando a varanda, 
    então, o mordomo estava sozinho em casa com a dona da casa.""",  # (p v q) -> r
    """É verdade que faxineira avistou o jardineiro com uma tesoura de poda no jardim ou 
     que o jardineiro disse que a faxineira estava limpando vidro quebrado na varanda?""",  # p v q

]

pistas_tab = [
    ["PISTAS"],
]

acoes = [
    ["Opções", "Ação"],
    ["1", "Interrogar"],
    ["2", "Acusar"],
    ["3", "Consultar pistas"],
]

suspeitos = [
    ["Opções", "Suspeitos"],
    ["1", "Faxineira"],
    ["2", "Jardineiro"],
    ["3", "Mordomo"],
]

# Gerar Tabela
def gen_tab(tabela):
    x = None
    if not tabela == "pistas_tab":
        x = "firstrow"
    print(tabulate(tabela, headers=x, tablefmt="fancy_grid"))


# Selecionar
def opt_select():
    while True:
        user_in = str(input("Selecione uma opção: ")).strip()
        if len(user_in) == 1 and user_in in '123':
            user_in = int(user_in)
            break
        print("--> Digite apenas um número entre 1 e 3!")
    return user_in
def typing_fx(text):
    while True:

        for i in range(len(text)):
            print(text[i], end="")
            sleep(choice(txt_fx_vel))
        sleep(0.03)
        sfx_typing.stop()
        break

while True:
    gen_tab(acoes)
    user_in = opt_select()
    if user_in == 1:  # Investigar
        gen_tab(suspeitos)
        user_in = opt_select()

        if user_in == 1:  # Faxineira
            if  contador_faxineira == 0:
                print("""Você pergunta à faxineira onde ela estava no momento do ocorrido.""")
        elif user_in == 2:  # Jardineiro
            pass
        else:  # Mordomo
            pass

    elif user_in == 2:  # Acusar
        if not len(pistas_tab) >= 4:
            print("--> Ainda está muito cedo para prender alguém. Obtenha mais pistas!")
            continue
        gen_tab(suspeitos)
        user_in = opt_select()

        if user_in == 1 or user_in == 2:  # Acusou o jardineiro ou a faxineira
            print("""
        ██████╗ ███████╗██████╗ ██████╗  ██████╗ ████████╗ █████╗
        ██╔══██╗██╔════╝██╔══██╗██╔══██╗██╔═══██╗╚══██╔══╝██╔══██╗
        ██║  ██║█████╗  ██████╔╝██████╔╝██║   ██║   ██║   ███████║
        ██║  ██║██╔══╝  ██╔══██╗██╔══██╗██║   ██║   ██║   ██╔══██║
        ██████╔╝███████╗██║  ██║██║  ██║╚██████╔╝   ██║   ██║  ██║
        ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝    ╚═╝   ╚═╝  ╚═╝

        É uma pena. Você deixou o assassino impune.
            """)
        else:  # Acusou o mordomo
            print("""
                                  █
        ██╗   ██╗██╗████████╗ ██████╗ ██████╗ ██╗ █████╗
        ██║   ██║██║╚══██╔══╝██╔═══██╗██╔══██╗██║██╔══██╗
        ██║   ██║██║   ██║   ██║   ██║██████╔╝██║███████║
        ╚██╗ ██╔╝██║   ██║   ██║   ██║██╔══██╗██║██╔══██║
         ╚████╔╝ ██║   ██║   ╚██████╔╝██║  ██║██║██║  ██║
          ╚═══╝  ╚═╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝╚═╝╚═╝  ╚═╝

        Parabéns, você acertou!
            """)
        break
    else:  # Mostrar pistas
        gen_tab(pistas_tab)

print("FIM.")
